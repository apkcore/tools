package com.example.apkcore.matissedemo;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.filter.Filter;
import com.zhihu.matisse.internal.entity.CaptureStrategy;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String authority = "com.example.apkcore.matissedemo.fileprovider";
    private static final int REQUEST_CODE_CHOOSE = 23;//定义请求码常量
    Button button;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textview);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Matisse.from(MainActivity.this)
                        .choose(MimeType.ofImage())//照片视频全部显示
                        .countable(true)//有序选择图片
                        .maxSelectable(5)//最大选择数量为9
                        .gridExpectedSize(getResources().getDimensionPixelSize(R.dimen.grid_expected_size))
//                .gridExpectedSize(120)//图片显示表格的大小getResources()
//                .getDimensionPixelSize(R.dimen.grid_expected_size)

                        .addFilter(new GifSizeFilter(320, 320, 5 * Filter.K * Filter.K))
                        .capture(true) //是否提供拍照功能
                        .originalEnable(true)
                        .maxOriginalSize(1)//设置原始照片最大尺寸M
                        .captureStrategy(new CaptureStrategy(true, authority))//存储到哪里
                        .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)//图像选择和预览活动所需的方向。
                        .thumbnailScale(0.85f)//缩放比例
                        .theme(R.style.MyZhihu)//主题  暗色主题 R.style.Matisse_Dracula
                        .imageEngine(new Glide4Engine())//加载方式
                        .forResult(REQUEST_CODE_CHOOSE);//请求码
            }
        });

    }

    //接收返回的地址
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CHOOSE && resultCode == RESULT_OK) {
            List<Uri> mSelected = Matisse.obtainResult(data);
            textView.setText(mSelected.toString());
        }
    }
}
